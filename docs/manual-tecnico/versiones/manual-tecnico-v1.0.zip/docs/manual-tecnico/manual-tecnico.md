# Manual Técnico de Software

**MAREA** · Versión documental 1.0 · 11 de noviembre de 2026

Cliente multiplataforma, backend de datos y servicios de procesamiento

<a id="cap-00"></a>
## 00 · Control documental

| Campo | Valor |
|---|---|
| Producto y paquete | MAREA · `marea` |
| Versión de la aplicación | `1.0.0+1`, declarada en `pubspec.yaml` |
| Revisión base | `e27f6ae4e3fb2a63f7287bbd486e989745bab216` |
| Fuente inspeccionada | Árbol de trabajo del 11 de noviembre de 2026, incluidos los cambios locales de Mapbox |
| Historial documental | 1.0 · Primera edición técnica |

**VERIFICADO** indica lectura directa de la implementación o una comprobación ejecutada, según se indique. **INFERIDO** identifica una consecuencia razonada a partir del código. **PENDIENTE DE VALIDACIÓN** identifica una comprobación que depende de infraestructura, credenciales, dispositivo o confirmación externa. Una evidencia histórica se cita con su fecha y alcance.

En las referencias, las rutas parten de la raíz de MAREA. En las figuras, las flechas indican dependencias, mensajes o claves foráneas según el tipo de diagrama. En el PDF, el índice y los marcadores llevan a los capítulos.

<!-- indice -->

- [00 · Control documental](#cap-00)
- [01 · Introducción](#cap-01)
- [02 · Visión general del sistema](#cap-02)
- [03 · Arquitectura de software](#cap-03)
- [04 · Tecnologías y dependencias](#cap-04)
- [05 · Organización del código fuente](#cap-05)
- [06 · Diseño e implementación de módulos](#cap-06)
- [07 · Arquitectura y modelo de datos](#cap-07)
- [08 · APIs y comunicación externa](#cap-08)
- [09 · Instalación y configuración](#cap-09)
- [10 · Compilación y despliegue](#cap-10)
- [11 · Seguridad del sistema](#cap-11)
- [12 · Pruebas y aseguramiento de calidad](#cap-12)
- [13 · Operación y mantenimiento](#cap-13)
- [14 · Limitaciones, riesgos y deuda técnica](#cap-14)
- [15 · Anexos técnicos](#cap-15)

<!-- fin-indice -->

<a id="cap-01"></a>
## 01 · Introducción

**VERIFICADO.** MAREA reúne perfiles, publicaciones y fichas profesionales con oportunidades de participación llamadas *misiones*. Permite descubrir contenido, colaborar, intercambiar mensajes y, para los flujos habilitados, editar y visitar recorridos panorámicos. Las funciones disponibles dependen de la sesión, el tipo de perfil, la propiedad y el estado del recurso. La interfaz y los contratos de datos corresponden al cliente Flutter, las migraciones y las funciones del repositorio. Véanse `lib/main.dart` · `startMarea()`, `lib/core/router/app_router.dart`, `supabase/migrations/001_initial_schema.sql`, `003_community.sql` y `015_tours.sql`.

El manual está dirigido a un ingeniero que recibe el sistema para mantenerlo, reproducir su entorno o preparar una entrega. Los requisitos de producto y su seguimiento se consultan en [MAREA_SRS.md](../MAREA_SRS.md) y [MAREA_REQUIREMENTS_STATUS.yaml](../MAREA_REQUIREMENTS_STATUS.yaml). Un requisito se presenta como comportamiento disponible solo cuando se identifica su camino de ejecución. La [auditoría técnica](auditoria-tecnica.md) y la [matriz de trazabilidad](matriz-trazabilidad.md) amplían la evidencia de esta edición.

<a id="cap-02"></a>
## 02 · Visión general del sistema

**VERIFICADO.** El modelo de perfil distingue `Usuario general`, `Artista / creador`, `Emprendedor` y `Negocio`. El rol de aplicación `user` o `admin` es un atributo separado. Autor, organizador, postulante, interlocutor y revisor representan relaciones con un recurso. La base y las RPC aplican estas relaciones en cada dominio. Véanse `001_initial_schema.sql` · restricciones de `profiles`, `003_community.sql`, `013_missions_redesign.sql`, `015_tours.sql`, `022_private_chat.sql`.

| Área | Capacidad que se puede seguir desde el código |
|---|---|
| Acceso y perfil | Registro, confirmación, recuperación, OAuth Google, política legal, configuración inicial, edición y eliminación de cuenta. |
| Comunidad | Publicaciones, fichas, guardados, reacciones, comentarios, colaboración, reportes y moderación. |
| Inicio y descubrimiento | Feed paginado, seguimiento, historias, búsqueda y mapa de misiones con filtros. |
| Misiones | Creación, borradores, edición, postulación, finalistas, selección y cambios de estado. |
| Comunicación | Solicitudes de chat, conversación, bloqueos, reportes, avisos internos y push Android condicionado. |
| Recorridos | Editor, panoramas conectados, captura guiada móvil, importación GPano, solicitudes y RA móvil compatible. |

*Tabla 1. Capacidades rastreadas desde el cliente. Las referencias por módulo figuran en el capítulo 06 y en la matriz.*

**PENDIENTE DE VALIDACIÓN.** Las pruebas con dispositivos físicos, cartografía real y servicios activos se gestionan por plataforma. La existencia de una ruta o una configuración de compilación permite identificar una capacidad de código. Su disponibilidad en un entorno distribuido requiere las comprobaciones del capítulo 10.

<a id="cap-03"></a>
## 03 · Arquitectura de software

**VERIFICADO.** `startMarea()` inicializa Flutter y Mapbox y configura rutas Web sin fragmento. `_StartupAppState._initializeApp()` valida `AppConfig`, inicializa Supabase e inyecta repositorios en `AppSessionController`. `MareaApp` conecta la sesión con `GoRouter`; el shell adapta navegación y vistas. El controlador de sesión y controladores como `MissionMapController`, `NotificationsController` y `PushController` usan `ChangeNotifier`. La UI también conserva estado local en widgets. Véanse `lib/main.dart`, `lib/app.dart`, `lib/core/router/app_router.dart` y `lib/core/session/app_session_controller.dart`.

![Contexto de MAREA](diagramas/01-contexto.svg)

*Figura 1. Contexto C4. Las personas interactúan con MAREA y sus servicios externos mediante el cliente, el backend o los procesos de servidor.*

**VERIFICADO.** Los repositorios traducen modelos Dart a llamadas de Supabase Auth, Data API, RPC, Storage, Edge Functions y streams de tablas. Las reglas que deben sostenerse ante varios clientes se implementan en PostgreSQL mediante restricciones, transacciones y políticas. Las Edge Functions median operaciones con privilegios o integraciones. El worker 360° ejecuta trabajo fuera de la petición de usuario. Véanse `lib/features/chat/data/chat_repository.dart` · `changes()`, `supabase/functions/`, `processing/tours/worker.py` · `process_job()`.

![Contenedores de MAREA](diagramas/02-contenedores.svg)

*Figura 2. Contenedores C4. Supabase reúne servicios con contratos distintos. El worker se ejecuta por separado y vuelve a Supabase para obtener trabajo y registrar resultados.*

**INFERIDO.** El patrón observable es una arquitectura modular por funcionalidad con repositorios inyectados, estado de presentación y reglas compartidas en la base. Las dependencias se ensamblan en el arranque. Las interfaces de repositorio facilitan sustituir el límite de I/O en pruebas y la separación del renderer de mapa permite probar filtros, gestos y resultados sin GPU.

![Componentes del cliente Flutter](diagramas/03-componentes.svg)

*Figura 3. Componentes del cliente. Las pantallas consumen controladores y repositorios, con adaptadores específicos para cartografía y funciones nativas.*

**VERIFICADO.** Las operaciones que compiten por estado usan mecanismos acordes con su dominio. El mapa descarta respuestas de generaciones antiguas. El chat y los avisos pueden observar cambios con streams. La selección de una misión bloquea su fila y valida cupo. Push y tours reclaman trabajo en base y comprueban la vigencia antes de completar. Los errores se traducen en el cliente con `AppFailureMapper`, `communityFailure()` y mapeos especializados. Véanse `lib/core/errors/app_failure.dart`, `lib/features/map/application/mission_map_controller.dart`, `013_missions_redesign.sql`, `014_android_push.sql` y `015_tours.sql`.

<a id="cap-04"></a>
## 04 · Tecnologías y dependencias

**VERIFICADO.** Las restricciones con `^` corresponden a `pubspec.yaml`, las versiones resueltas a `pubspec.lock`. El SDK observado para esta inspección coincide con la revisión declarada en `.metadata`. Los componentes nativos y del worker tienen sus propios archivos de referencia.

| Tecnología | Versión o restricción identificada | Responsabilidad | Evidencia |
|---|---|---|---|
| Flutter y Dart | 3.44.1 / 3.12.1 en SDK local. El lockfile requiere Flutter desde 3.44.0, Dart desde 3.12.1 y menor que 4.0.0 | Runtime, widgets Material y toolchain | `.metadata`, `pubspec.lock`, SDK local |
| `supabase_flutter` | `^2.17.2` a `2.17.2` | Auth, datos, RPC, medios y Realtime | `pubspec.yaml`, `pubspec.lock` |
| `go_router` | `^17.4.0` a `17.5.0` | Rutas, shell y redirecciones | `pubspec.lock`, `app_router.dart` |
| Mapbox Flutter / Web | `3.34.2` / `3.34.2` | Renderizado cartográfico y cámara | `pubspec.lock`, `lib/core/maps/` |
| Geolocator / latlong2 | `14.0.3` / `0.9.1` | Ubicación puntual y geometría | `pubspec.lock`, `lib/core/location/` |
| Firebase Core / Messaging | `4.15.0` / `16.7.0` | Inicialización y push Android | `pubspec.lock`, `android_push_gateway.dart` |
| Avisos locales / preferencias | `22.3.1` / `2.5.5` | Presentación de avisos y persistencia local | `pubspec.lock`, `lib/features/notifications/` |
| Camera / Panorama Viewer | `0.12.1` / `2.0.7` | Captura y visita panorámica | `pubspec.lock`, `lib/features/tours/` |
| Image Picker / File Selector | `1.2.3` / `1.1.0` | Selección de imágenes o archivos | `pubspec.lock`, `profile_media_repository.dart` |
| Android | Gradle `9.1.0`, AGP `9.0.1`, Kotlin `2.3.20`, JVM objetivo `17`, `minSdk 24` | Compilación, identidad y canales nativos | `android/settings.gradle.kts`, `android/app/build.gradle.kts`, wrapper |
| iOS | Objetivo `15.0`, Mapbox Maps iOS `11.34.2` | Runner y dependencias SwiftPM | `ios/Runner.xcodeproj/project.pbxproj`, `Package.resolved` |
| Python y herramientas 360° | Python `3.12` sobre Bookworm. Pillow `11.3.0`, NumPy `2.2.6`, Requests `2.32.5` | Validación, proyección y exportación JPEG. Hugin y Enblend se instalan en la imagen | `processing/tours/Dockerfile`, `requirements.txt` |
| Node y YAML | Node `24` en la guía, YAML `2.9.1` fijado | Gate, pruebas y trazabilidad de requisitos | `tool/README.md`, `tool/traceability/package.json` |

*Tabla 2. Versiones declaradas, resueltas u observadas según la evidencia. La versión del PostgreSQL alojado y del runtime remoto de Edge Functions quedan pendientes de validación.*

<a id="cap-05"></a>
## 05 · Organización del código fuente

**VERIFICADO.** `lib/main.dart` es la entrada ordinaria. Los arneses de mapa y RA residen en `test/`. `lib/core/` mantiene servicios compartidos, enrutamiento, sesión y configuración. Los dominios agrupan modelos, acceso a datos y presentación según su tamaño.

```text
lib/
  main.dart, app.dart     Arranque y raíz de la aplicación
  core/                   Configuración, rutas, sesión, mapas y errores
  features/
    auth, legal, profile  Acceso, consentimiento y perfil
    community, showcase  Publicaciones, misiones, moderación y fichas
    home_feed, discover  Inicio, historias y descubrimiento
    map, location        Consulta geográfica y geocodificación
    chat, notifications  Conversaciones, bandeja y push
    tours, shell         Recorridos, RA y navegación adaptativa
  shared/widgets/         Componentes reutilizables
android/, ios/, web/      Entradas y configuración por plataforma
supabase/
  migrations/            Esquema y contratos SQL
  functions/             Edge Functions TypeScript
  email-templates/       Plantillas de Auth
processing/tours/        Imagen, worker, scripts y pruebas 360°
config/                  Ejemplos de configuración
assets/                  Marca, fuentes e introducción
test/                   Pruebas y arneses de QA
tool/                   Gates, verificadores y laboratorios
docs/                   Documentación y evidencia histórica
```

Para localizar una operación, partir de la ruta y seguir la construcción de la pantalla. Buscar el método del repositorio y el literal que identifica la tabla, RPC, bucket o función. Revisar las redefiniciones SQL posteriores y la prueba asociada antes de deducir el contrato efectivo. Los anexos ofrecen referencias para los flujos más sensibles.

<a id="cap-06"></a>
## 06 · Diseño e implementación de módulos

### 6.1 Acceso, consentimiento y perfil

**VERIFICADO.** `SupabaseAuthRepository` conecta correo y contraseña, confirmación, recuperación y OAuth con Auth. El registro mínimo usa metadatos para que el trigger inicialice el perfil y confirme el tipo cuando la entrada cumple su contrato. `SupabaseLegalRepository` consulta `registration_policy` y registra la aceptación de las versiones vigentes mediante `accept_current_legal`. El controlador carga la política y el perfil, escucha cambios de sesión, normaliza fallos y limpia localmente una sesión identificada como inválida. Las pantallas de registro y configuración validan los campos antes de enviar. El servidor vuelve a aplicar restricciones de tipo, nombre y username. Véanse `lib/features/auth/data/auth_repository.dart`, `lib/features/legal/legal_repository.dart`, `lib/core/session/app_session_controller.dart`, `002_account_completion.sql`, `007_minimal_registration.sql` y `008_recover_minimal_registration.sql`.

![Secuencia de acceso](diagramas/04-secuencia-acceso.svg)

*Figura 4. Secuencia de restauración de sesión. El controlador informa al router cuando termina la carga. Las rutas legales públicas siguen accesibles durante el proceso.*

**VERIFICADO.** `AppRouter.redirectFor()` prioriza inicialización, acceso, recuperación, aceptación legal y onboarding para rutas protegidas. El guard admite destinos internos de contenido según una lista de rutas. `SupabaseProfileRepository` carga la fila propia y usa `community_profiles` para los datos de presentación de terceros. Avatar y portada utilizan `SupabaseProfileMediaRepository`; primero se obtiene la ruta del medio y luego se actualiza el perfil. La función evita eliminar una imagen aún referenciada. Un fallo de carga legal deja un estado de política no disponible y se puede reintentar. Véanse `app_router.dart`, `profile_repository.dart`, `profile_media_repository.dart`, `supabase/functions/profile-media/index.ts` y `035_profile_public_interests.sql`.

### 6.2 Comunidad, descubrimiento y escaparates

**VERIFICADO.** `SupabaseCommunityRepository` crea, edita, lista y consulta publicaciones y misiones. Las publicaciones se validan según el tipo de contenido y se persisten con autor, texto, categoría y campos opcionales de ubicación e imagen. Guardados y reportes se almacenan por usuario. `SupabaseSocialRepository` gestiona reacciones, comentarios e interés de colaboración, y devuelve las proyecciones necesarias para pintar contadores, estados y avisos. RLS y RPC determinan qué cuenta puede escribir y qué contenido puede ver. La moderación depende del rol y distingue contenido reportado de las operaciones para ocultarlo. Véanse `lib/features/community/data/`, `lib/features/community/presentation/moderation_screen.dart`, migraciones `003`, `009`, `010` y `011`.

**VERIFICADO.** `SupabaseShowcaseRepository` administra fichas profesionales y fotos independientes de las publicaciones. Una ficha tiene dueño, tipo, estado y disponibilidad. El detalle y las operaciones de guardar o editar consultan contratos diferenciados. La búsqueda usa las proyecciones de comunidad y escaparate disponibles para la cuenta. El medio se lee según visibilidad y permisos del bucket. Véanse `lib/features/showcase/data/showcase_repository.dart`, `lib/features/discover/presentation/`, `006_profile_experience.sql`.

### 6.3 Inicio, seguimiento e historias

**VERIFICADO.** `SupabaseHomeFeedRepository.page()` valida filtros y envía `filters` y `page_cursor` a `home_feed`. El servidor devuelve una página de contenido mixto a partir de candidatos y un snapshot asociado al usuario. El cliente distingue `feed_cursor_expired` para solicitar una actualización. El seguimiento usa `set_profile_follow` y el estado se consulta bajo permisos de la cuenta. Véanse `lib/features/home_feed/data/home_feed_repository.dart` y `016_home_feed.sql`.

**VERIFICADO.** `SupabaseStoriesRepository` carga `stories` y `server_time`, prepara rutas de imagen por autor e ID, y envía cinco argumentos a `publish_story`. Un recibo persistente permite distinguir el reintento de un cambio de contenido. Las vistas, reportes, moderación y limpieza siguen contratos separados. La visibilidad se acota por el estado de la historia y su expiración. La limpieza quita imágenes, filas vencidas o eliminadas y snapshots expirados. Véanse `stories_repository.dart`, migraciones `016`–`019` y `034_story_metadata.sql`–`040_restore_story_metadata_columns.sql`, `supabase/functions/story-cleanup/index.ts`.

### 6.4 Misiones y postulaciones

**VERIFICADO.** La creación y la edición preparan un documento de misión validado por RPC. Los borradores pertenecen al autor y registran la misión publicada cuando se materializan. Las postulaciones incluyen mensaje, disponibilidad afirmativa, hasta tres muestras y un ID de operación. Cada muestra apunta a una URL HTTPS válida o a una ficha propia publicada y disponible. `submit_mission_application` valida el contrato y devuelve un UUID. El mismo ID con contenido diferente produce conflicto. La selección comprueba propiedad, disponibilidad temporal, candidaturas pertenecientes a la misión y capacidad. `confirm_mission_selection` bloquea la fila de misión y procesa candidaturas pendientes en la misma transacción. Véanse `community_repository.dart`, `community_models.dart`, `mission_experience.dart`, `005_mission_lifecycle.sql`, `013_missions_redesign.sql` y redefiniciones de creación y borradores en `021_content_cities.sql`.

![Secuencia de selección](diagramas/05-secuencia-misiones.svg)

*Figura 5. Secuencia de selección de misión. El servidor comprueba cupo y estado con la fila de misión bloqueada. Los cambios de estado pueden generar notificaciones.*

**VERIFICADO.** El organizador puede marcar finalistas y confirmar selección. La RPC acepta misiones `open` o `closed` mientras cumplan las demás condiciones. La confirmación actual actualiza la candidatura a `accepted` desde la acción del organizador. Reacciones y comentarios de misión usan sus propias tablas y RPC, y la versión de eventos permite distinguir transiciones para avisos. Véanse `013_missions_redesign.sql` · `set_mission_finalist`, `confirm_mission_selection`, `version_mission_event`, `020_mission_social.sql`.

### 6.5 Mapa y geocodificación

**VERIFICADO.** `MissionMapController` combina viewport, texto y filtros. Una búsqueda explícita consulta `list_map_missions`, que considera límites, categoría, fecha y radio, y retorna `missions` y `total`. El contrato limita el resultado a 300 filas y admite límites que cruzan el antimeridiano. La UI conserva resultados al fallar y descarta respuestas obsoletas. Un desplazamiento de cámara puede habilitar «Buscar en esta zona». La ubicación puntual utiliza permisos del dispositivo y el gesto del usuario puede cancelar el recentrado pendiente. Véanse `lib/features/map/application/mission_map_controller.dart`, `mission_map_repository.dart`, `mission_map_models.dart`, `lib/core/location/`, `012_mission_map.sql`.

**VERIFICADO.** `MareaMapSurface` integra Mapbox Standard, estilos y capas, clusters calculados en Dart y selección de puntos. El selector de ubicación utiliza una superficie compartida en modo cenital. Conserva el redondeo de coordenadas aproximadas antes de consultar o guardar. El SDK visual depende de `MAPBOX_ACCESS_TOKEN`. Una Edge Function resuelve la geocodificación. `SupabaseLocationRepository` deduplica solicitudes en curso y cachea respuestas resueltas en memoria. La Edge Function usa caché PostgreSQL y un lease para limitar solicitudes al proveedor. `content_city` usa las coordenadas almacenadas del contenido visible. Véanse `lib/core/maps/`, `post_location_picker.dart`, `location_repository.dart`, `021_content_cities.sql` y `supabase/functions/geocoding/index.ts`.

### 6.6 Chat, bandeja y push

**VERIFICADO.** `SupabaseChatRepository` lista conversaciones y mensajes, envía solicitudes y llama a RPC para aceptar, rechazar, enviar, bloquear o reportar. El acceso a lectura se restringe a participantes mediante RLS. `changes()` usa un stream filtrado por conversación; la disponibilidad de eventos depende de la publicación Realtime del entorno. Las redefiniciones SQL ajustan avisos agrupados y censura. `027_disable_chat_bans.sql` retira la comprobación de suspensiones de `chat_active_account`, mientras el bloqueo entre interlocutores permanece en el contrato. Véanse `lib/features/chat/data/chat_repository.dart`, `022_private_chat.sql`–`033_censor_entire_chat_message.sql`.

**VERIFICADO.** La bandeja de la aplicación lee `notifications` y registra lectura. `PushController` controla la sesión del dispositivo, permisos y sincronización de token. `startMarea()` usa `AndroidPushGateway` en Android nativo con configuración ordinaria. Para Web, iOS, desarrollo y piloto utiliza `InboxOnlyGateway`. La cola privada de push reclama trabajos, consulta si siguen vigentes y registra el resultado del envío FCM. El envío requiere configuración del cliente, del worker y activación del entorno. Véanse `lib/main.dart`, `lib/features/community/data/notifications_controller.dart`, `lib/features/notifications/data/`, `014_android_push.sql`, `supabase/functions/send-push/index.ts`.

### 6.7 Recorridos 360° y realidad aumentada

**VERIFICADO.** El editor guarda el documento de recorrido, zonas, escenas y puntos de RA. Las capturas y originales tienen acceso restringido. Los envíos y solicitudes guardan una revisión, y la publicación deriva de permisos y decisiones del servidor. La visita recupera escenas enlazadas y registra progreso por revisión y usuario. La RA usa canales `marea/tour_ar` y `marea/tour_ar/events` con Android ARCore o iOS ARKit. El reporte de reconocimiento queda ligado a la versión de referencia y su ancho físico. La captura guiada utiliza canales de movimiento y la importación acepta panoramas con GPano verificado por el worker. Véanse `lib/features/tours/`, `android/app/src/main/kotlin/com/marea/app/TourAR.kt`, `TourNative.kt`, `ios/Runner/AppDelegate.swift`, `015_tours.sql`.

![Secuencia de procesamiento 360](diagramas/06-secuencia-tours.svg)

*Figura 6. Secuencia de procesamiento 360°. Captura, reclamación, procesamiento y asociación de salida son pasos separados. El resultado se registra bajo un lease vigente.*

**VERIFICADO.** `tours_capture_begin` y `tours_capture_submit` enlazan captura, manifiesto y job. El dispatcher reclama la cola e invoca Cloud Run. `worker.py` verifica identidad, rutas y metadatos, procesa JPEG importado o une fotos con Hugin y Enblend, y escribe JPEG GPano, preview y miniatura. Comprueba lease antes de escribir y concluir. La cola admite dos trabajos globales y hasta tres intentos por job. Los errores transitorios se pueden reencolar y los datos inválidos producen un resultado terminal. Véanse `supabase/functions/tour-dispatch/index.ts`, `processing/tours/worker.py` · `process_job()`, `015_tours.sql` · `tours_claim_jobs`, `tours_finish_job`.

<a id="cap-07"></a>
## 07 · Arquitectura y modelo de datos

**VERIFICADO.** PostgreSQL persiste la identidad de aplicación, contenido y trabajos. `profiles.id` referencia `auth.users.id` con borrado en cascada. `public` agrupa tablas y RPC de aplicación, con exposición controlada por permisos y RLS. `private` mantiene estado de servicios como colas, leases y permisos 360°. Los datos binarios se guardan en Storage. Los documentos JSONB son parte del contrato en misiones, historias, snapshots y recorridos según la entidad.

![Datos de identidad, comunidad y misiones](diagramas/07-er-comunidad.svg)

*Figura 7. Claves foráneas principales de identidad, contenido y misiones. Las flechas van de la tabla dependiente a su tabla referenciada.*

| Familia | Identificadores, relaciones y reglas principales | Migraciones |
|---|---|---|
| Identidad y legal | `profiles.id` es PK y FK de `auth.users`. Username normalizado con índice único. `legal_acceptances` guarda aceptación por usuario y par de versiones de términos y privacidad. `account_deletion_requests` y `profile_media_operations` coordinan baja y medios. | `001`, `002`, `007`, `008`, `034_profile_wave_colors`, `035_profile_public_interests` |
| Comunidad | `posts.author_id` referencia un perfil. `post_saves`, `post_reactions`, `post_comments` y `post_collaboration_interests` se vinculan a publicación y perfil. `content_reports` admite referencia de publicación o misión. | `003`, `004`, `009`–`011` |
| Misiones | `missions.author_id` referencia un perfil. `mission_applications` vincula misión y postulante. Guardados y finalistas relacionan usuario, misión o candidatura. `mission_application_operations` usa `(applicant_id, operation_id)`. | `003`, `005`, `012`, `013`, `020`, `021` |
| Escaparates | `showcase_items.owner_id` referencia un perfil. `showcase_images` y `showcase_saves` dependen de la ficha. Las fotos se relacionan por ruta de objeto. | `006` |
| Feed e historias | `profile_follows` vincula perfiles. `stories.author_id` referencia un perfil. `story_views` y `story_reports` vinculan historia y usuario. `story_publications` guarda recibo de operación. `home_feed_snapshots` guarda un cursor ligado al usuario. | `016`–`019`, `034_story_metadata`, `036`–`040` |
| Chat y avisos | Conversaciones con dos perfiles, mensajes con conversación y remitente. Bloqueos y reportes se guardan por cuenta. `notifications` conserva destinatario, actor y referencias según el evento. Preferencias, dispositivos y `private.push_queue` controlan el canal push. | `009`, `013`, `014`, `022`–`033` |
| Recorridos | `tours.owner_id` referencia un perfil. Revisiones, solicitudes y capturas dependen del recorrido. `tour_jobs.capture_id` es único. `tour_output_writes.job_id` guarda la protección de escritura. `tour_progress` usa `(revision_id, user_id)`. | `015` |
| Geocodificación | `geocoding_provider` guarda configuración y lease. `geocoding_cache` tiene `cache_key` y `payload`. Cambios de punto invalidan la ciudad derivada cuando corresponde. | `021` |

*Tabla 3. Modelo relacional por dominio. Los diagramas muestran las relaciones que ayudan a seguir los flujos. El DDL conserva las restricciones completas.*

![Datos de feed, chat y notificaciones](diagramas/08-er-social.svg)

*Figura 8. Relaciones principales de historias, chat y avisos. Las tablas de coordinación sin FK directa quedan descritas en la tabla 3.*

![Datos de recorridos 360](diagramas/09-er-tours.svg)

*Figura 9. Relaciones principales de recorridos, revisiones y trabajos. El esquema `private` aparece como prefijo de las tablas correspondientes.*

### 7.1 Objetos y consistencia

**VERIFICADO.** Las migraciones declaran privados `profile-media`, `post-images`, `mission-images`, `showcase-media` y `story-images` para PNG de hasta 4 MiB, y `tour-inputs` y `tour-assets` para JPEG de hasta 32 MiB por objeto. Las políticas de `storage.objects` validan rutas, pertenencia y visibilidad según el bucket. Cuando el cliente obtiene una URL firmada, la vigencia depende del consumidor. `SupabaseStoriesRepository.imageUrl()` solicita 60 segundos y el cliente de tours solicita 600 segundos para medios de recorrido. Véanse migraciones `002`, `003`, `005`, `006`, `015` y `016`, `stories_repository.dart`, `tour_repository.dart`.

**VERIFICADO.** Las restricciones de base, los recibos de operación, los bloqueos de filas y los leases son mecanismos distintos de integridad. Una cascada de PostgreSQL elimina filas dependientes del usuario. La función de baja gestiona aparte los objetos y verifica escrituras activas. Las copias de la base y de Storage requieren procedimientos propios de restauración y verificación. Véanse `supabase/functions/delete-account/`, `002_account_completion.sql` y `015_tours.sql`.

### 7.2 Migraciones y orden efectivo

**VERIFICADO.** Hay 42 archivos con prefijos `001`–`040`. `034` identifica `034_profile_wave_colors.sql` y `034_story_metadata.sql`. `035` identifica `035_profile_public_interests.sql` y `035_reload_postgrest_schema.sql`. Para historias, `039_remove_legacy_story_rpc.sql` retira la variante de tres parámetros y `040_restore_story_metadata_columns.sql` repara columnas y refresca el esquema PostgREST. El comentario de `040` describe un antecedente remoto. El archivo demuestra la reparación prevista en el código.

**PENDIENTE DE VALIDACIÓN.** Antes de aplicar migraciones en un entorno, comparar sus archivos, firmas y dependencias con el historial de migraciones del destino. Los prefijos repetidos y las redefiniciones de `publish_story` requieren especial revisión. El esquema alojado, el orden de los cambios ya aplicados y la restauración coordinada de objetos no se verificaron en esta edición.

<a id="cap-08"></a>
## 08 · APIs y comunicación externa

**VERIFICADO.** Las rutas de `GoRouter` son rutas de interfaz. El cliente usa Auth, PostgREST, Storage, Realtime y Edge Functions en Supabase. El repositorio no incluye un servidor HTTP propio para servir la aplicación Flutter. La siguiente tabla resume las superficies HTTP de código propio. Las rutas corresponden a `/functions/v1/<nombre>` en el origen Supabase configurado.

| Edge Function | Solicitud y autorización | Respuesta y fallos representativos |
|---|---|---|
| `delete-account` | `POST`. Gateway con JWT y comprobación de usuario mediante Auth. Identidad tomada del bearer. | `204` tras completar la baja. `401` para sesión ausente o inválida, `409` con operación de medios activa, `503` si queda limpieza por completar. |
| `profile-media` | `POST` con bytes `image/png` o `DELETE` con `{path}`. Gateway con JWT, usuario y guarda de operación. | `201` con `{path}` al subir, `200` con `{ok:true}` al borrar. `409` para medio en uso o guarda no disponible, `413` por tamaño, `415` por MIME. |
| `geocoding` | `POST` JSON con `search`, `reverse` o `content_city`. Los dos primeros permiten uso previo al registro. `content_city` valida usuario y lectura de contenido bajo RLS. | `200` con `places`, `place` o `city`. `409` ante cambio de coordenadas, `429` por lease u ocupación, `503` ante indisponibilidad. |
| `send-push` | `POST` con `x-marea-worker-secret`. Reclama trabajos y usa credencial de servidor para FCM HTTP v1. | `200` con `processed` y `sent`. `401` para credencial de worker inválida y `503` ante indisponibilidad. |
| `story-cleanup` | `POST` con `x-story-worker-secret`. Borra imágenes antes de eliminar filas y expira snapshots. | `200` con `removed`, `403` para solicitud no autorizada, `503` ante un fallo que puede reintentarse en la próxima corrida. |
| `tour-dispatch` | `POST` con bearer de worker. Reclama jobs y activa Cloud Run mediante OAuth de cuenta de servicio. | `200` con `dispatched`, `401` por autorización y `503` si falta configuración o no puede reclamar trabajo. |

*Tabla 4. Métodos y contratos HTTP. Evidencia directa en `supabase/config.toml` y en los seis `index.ts` de `supabase/functions/`.*

**VERIFICADO.** Los nombres de campos del siguiente intercambio provienen del handler. El ejemplo emplea coordenadas ficticias y muestra el error que devuelve el validador antes de consultar al proveedor.

```http
POST /functions/v1/geocoding HTTP/1.1
Host: ejemplo.supabase.co
Content-Type: application/json

{"mode":"reverse","latitude":91,"longitude":0}

HTTP/1.1 400 Bad Request
Content-Type: application/json

{"error":"invalid_point"}
```

Los contratos RPC más útiles al diagnosticar la integración son `list_map_missions` devuelve `{missions,total}` para los filtros y la zona. `home_feed` entrega una página por filtro y cursor. `publish_story`, `submit_mission_application` y `send_chat_message` devuelven un UUID. `confirm_mission_selection` actualiza las candidaturas seleccionadas sin devolver datos de negocio. Véanse repositorios de los módulos y migraciones enlazadas en la [matriz](matriz-trazabilidad.md).

**VERIFICADO.** Google OAuth se inicia a través de Supabase Auth. Correo de confirmación y recuperación dependen de Auth, sus plantillas y del correo configurado en el proyecto. Mapbox entrega la cartografía directamente al SDK. `geocoding` usa una URL de proveedor configurable con Nominatim como valor inicial, búsqueda acotada a México y idioma `es-MX`. FCM es el transporte de push Android. Cloud Run ejecuta el job fuera del request del cliente. Véanse `auth_repository.dart`, `supabase/email-templates/`, `021_content_cities.sql`, `supabase/functions/` y `processing/tours/deploy.sh`.

<a id="cap-09"></a>
## 09 · Instalación y configuración

### 9.1 Preparar el entorno

**VERIFICADO.** Usar el checkout entregado por el equipo, con su lockfile, y un SDK Flutter compatible con la tabla 2. Desde la raíz, revisar `flutter doctor -v` y `flutter devices`, y resolver con `flutter pub get`. Para Android se necesita toolchain Android y dispositivo o emulador. Para iOS se necesita macOS con Xcode, SwiftPM y simulador o dispositivo. Para la ejecución Web local se puede utilizar Chrome. La CLI de Supabase se usa para administrar o verificar el backend. Para arrancar el cliente basta un proyecto ya preparado con su URL y clave pública. Véanse `README.md`, `.metadata`, `android/`, `ios/`, `web/` y `tool/README.md`.

### 9.2 Configurar el cliente

```sh
cp config/supabase.example.json config/supabase.local.json
flutter pub get
flutter run -d chrome -t lib/main.dart --web-port 7357 \
  --dart-define-from-file=config/supabase.local.json
```

Editar `config/supabase.local.json` antes de ejecutar. Guardar la URL y la clave pública del proyecto autorizado. Los nombres de variables del cliente pueden quedar visibles en el binario, así como sus valores. Mantener credenciales de servidor y claves de firma fuera de los defines.

| Define | Uso observado |
|---|---|
| `SUPABASE_URL`, `SUPABASE_ANON_KEY` | Origen y clave pública. El SDK recibe la clave en `publishableKey`. |
| `MAREA_ENV` | `production` por defecto o `development` para la variante aislada. |
| `MAREA_PRODUCTION_SUPABASE_URL`, `APP_PUBLIC_URL` | En desarrollo, permiten comprobar separación de backend y definir el origen de enlaces y callbacks. |
| `MAPBOX_ACCESS_TOKEN` | Token público con prefijo `pk.` Pasarlo mediante `--dart-define` o archivo local de defines. |
| `FIREBASE_APP_ID`, `FIREBASE_API_KEY`, `FIREBASE_MESSAGING_SENDER_ID`, `FIREBASE_PROJECT_ID` | Configuración pública para push Android. Gradle requiere los cuatro valores juntos cuando se proporcionan. |

*Tabla 5. Configuración del cliente. Véanse `lib/core/config/app_config.dart`, `mapbox_configuration.dart`, `lib/main.dart` y `android/app/build.gradle.kts`.*

**VERIFICADO.** Para probar Android o iOS, sustituir `chrome` por el identificador reportado por `flutter devices` y omitir `--web-port`. Añadir el argumento siguiente cuando se necesite cartografía real. `MAREA_ENV=development` valida un destino separado, clave pública y origen local o HTTPS según el caso. Para preparar esa variante, seguir [piloto de desarrollo](../implementation/ar-development-pilot.md).

```sh
--dart-define=MAPBOX_ACCESS_TOKEN="$MAPBOX_ACCESS_TOKEN"
```

**VERIFICADO.** Configurar en Auth las URLs permitidas para `http://localhost:7357` y, si procede, el callback Android `com.marea.app://login-callback`. El callback de desarrollo usa `com.marea.app.dev://login-callback`. En Google se registra el callback de Supabase `https://<project-ref>.supabase.co/auth/v1/callback`. La guía del repositorio documenta las plantillas, el proveedor OAuth y la activación del registro. Véanse `README.md`, `app_config.dart`, `auth_repository.dart`, `supabase/email-templates/` y [correo](../email-setup.md).

### 9.3 Comprobación de arranque

**VERIFICADO EN CÓDIGO.** Con defines ausentes se muestra `ConfigurationScreen`. Con un proyecto preparado, comprobar que aparezca bienvenida o se restaure la sesión, que un perfil de prueba pueda leer datos propios y que el feed cargue. Sin token Mapbox se muestra configuración pendiente para el mapa. Las credenciales de Auth y los servicios reales deben validarse en el entorno correspondiente. Los comandos anteriores proceden del repositorio. En esta edición se ejecutaron las comprobaciones locales enumeradas en el capítulo 12.

<a id="cap-10"></a>
## 10 · Compilación y despliegue

### 10.1 Cliente y artefactos

**VERIFICADO.** Los comandos de referencia producen `build/web/`, `build/app/outputs/flutter-apk/app-debug.apk` y una compilación iOS sin firma. Añadir los defines de Mapbox y de Firebase que correspondan al destino. La distribución Android requiere revisar firma y artefacto. La configuración de `release` inspeccionada usa la firma `debug`; la firma de distribución y el pipeline de publicación quedan pendientes. La compilación iOS sin firma no acredita distribución ni prueba física. Véanse `README.md`, `android/app/build.gradle.kts`, `ios/Runner.xcodeproj/project.pbxproj` y `docs/mapbox-validation.md`.

```sh
flutter build web -t lib/main.dart \
  --dart-define-from-file=config/supabase.local.json
flutter build apk --debug -t lib/main.dart \
  --dart-define-from-file=config/supabase.local.json
flutter build ios --no-codesign -t lib/main.dart \
  --dart-define-from-file=config/supabase.local.json
```

**VERIFICADO.** El uso de rutas limpias exige que el alojamiento sirva `/index.html` con estado 200 al pedir una ruta de cliente. Revisar una recarga directa de una ruta como `/profile`. No se encontró un workflow de CI/CD versionado para la aplicación. La documentación anterior describe configuraciones y ejecuciones históricas. Véanse `lib/main.dart` · `usePathUrlStrategy()`, `README.md` y [estado de despliegue](../deployment-status.md).

![Topología de despliegue](diagramas/10-despliegue.svg)

*Figura 10. Topología descrita por la configuración y las guías del repositorio. El laboratorio es una alternativa de ejecución para pruebas. La activación remota se verifica por entorno.*

### 10.2 Backend y activación de procesos

**VERIFICADO.** Los gates de `tool/` consultan el proyecto enlazado mediante CLI y SQL de lectura. El principal cubre el contrato hasta `015`. Los de feed y corrección cubren `016`–`019` y `020`–`021` respectivamente. Verificar aparte chat, firmas actuales de historias y migraciones posteriores. Los siguientes comandos se documentan para operadores con acceso al entorno de destino.

```sh
node tool/check_backend_contract.mjs
node tool/check_home_feed_contract.mjs
node tool/check_feed_correction_contract.mjs
```

**PENDIENTE DE VALIDACIÓN.** La guía incluye `supabase link --project-ref <ref>` y `supabase db push --linked` como procedimiento remoto. Confirmar el destino y reconciliar el historial y los prefijos antes de aplicar SQL. Desplegar solo las Edge Functions requeridas y comprobar su configuración efectiva de JWT, secretos e integraciones. Revisar de forma separada SMTP, OAuth, política legal y registro habilitado. No se aplicaron migraciones ni se desplegaron funciones durante la elaboración del manual.

**VERIFICADO.** `017_story_cleanup_schedule.sql` define limpieza horaria. Push tiene activación explícita en `supabase/push/activate.sql`. Tours usa `processing/tours/deploy.sh` para preparar un Cloud Run Job de 4 CPU, 8 GiB, 900 segundos, un task y sin reintentos propios de Cloud Run. `processing/tours/activate.sql` programa despacho periódico después de preparar los secretos y validar el worker. PostgreSQL controla los reintentos de trabajos. El laboratorio descrito en [procesador 360°](../../processing/tours/README.md) ofrece una ruta local. La activación efectiva, facturación y funcionamiento de cada servicio quedan pendientes por entorno.

<a id="cap-11"></a>
## 11 · Seguridad del sistema

**VERIFICADO.** Auth entrega la sesión al SDK. El router controla la navegación y los repositorios operan con la sesión actual. Los controles de datos se aplican en RLS, grants, restricciones, ownership y comprobaciones de RPC. `002_account_completion.sql` retira la lectura anónima directa de username que aparece en `001`. La disponibilidad se expone por una RPC booleana y la proyección `community_profiles` entrega campos de presentación. La configuración de desarrollo y el piloto separan el almacenamiento de sesión mediante claves específicas de SharedPreferences. Véanse `lib/main.dart`, `AppRouteGuard`, migraciones `001`, `002`, `007` y `035_profile_public_interests`.

**VERIFICADO.** La función de baja obtiene la identidad del usuario a partir de Auth, solicita un estado de eliminación en la base, limpia siete buckets y elimina la cuenta. La rama 360° coordina cancelación y guardas de escritura. `profile-media` comprueba identidad, propiedad, tipo, tamaño y estructura PNG antes de escribir. Las políticas de los demás buckets se deben evaluar individualmente. Los límites y códigos de las Edge Functions se resumen en el capítulo 08. Véanse `supabase/functions/delete-account/`, `supabase/functions/profile-media/` y `002_account_completion.sql`, `015_tours.sql`.

**VERIFICADO.** `send-push`, `story-cleanup` y `tour-dispatch` usan secretos de servicio propios y `verify_jwt=false` en `supabase/config.toml`. `geocoding` tiene esa misma configuración de gateway y valida Auth al resolver ciudad de contenido. Los permisos elevados se inicializan en servidor. Mantener `SUPABASE_SERVICE_ROLE_KEY`, `FCM_SERVICE_ACCOUNT_JSON`, `TOUR_GOOGLE_SERVICE_ACCOUNT_JSON` y los secretos de worker en sus almacenes de servidor. Los nombres de secretos de Vault y requisitos de rotación operativa se consultan en las guías de servicio.

**INFERIDO.** Conviene tratar una URL firmada como acceso temporal hasta su vencimiento. Evaluar la exposición según el consumidor y la vigencia aplicable. La revocación efectiva de una sesión eliminada depende además de la expiración y de las comprobaciones que realiza cada operación. La edición no comprueba revocación en infraestructura. La auditoría relaciona controles observados y hallazgos con sus fuentes.

<a id="cap-12"></a>
## 12 · Pruebas y aseguramiento de calidad

| Comprobación | Resultado y alcance |
|---|---|
| Flutter `analyze --no-pub` | Sin incidencias en una copia temporal con el SDK local y resolución de dependencias existente. |
| Flutter `test --no-pub --reporter expanded` | **653 aprobadas, 2 omitidas y 17 fallidas.** Fallaron 7 de `mobile_intro_test.dart`, 3 de `home_feed_experience_test.dart` y 7 de `showcase_flow_test.dart`. Se ejecutó con el socket loopback del runner y una carpeta temporal de salida para la prueba visual. |
| Node `--test` | **55 aprobadas**. Trazabilidad, gate con CLI simulada y geocodificación con fixtures, incluida la vigencia del lease. |
| Python `unittest` | **16 aprobadas** en `test_worker.py`. Incluye validación e importación JPEG/GPano con almacenamiento simulado, integridad geométrica y ramas de cancelación. |
| Historial Mapbox, 7 de noviembre de 2026 | `docs/mapbox-validation.md` registra 54 pruebas dirigidas aprobadas, una suite histórica con 649 aprobadas, 2 omitidas y 17 fallidas, y compilaciones Web, APK debug e iOS sin firma. Las comprobaciones de arranque se hicieron sin token válido. |

*Tabla 6. Validaciones de la inspección e historial fechado. Los recuentos Flutter de ambas fechas tienen el mismo reparto de fallos por archivo.*

**VERIFICADO.** `test/core/` cubre configuración, sesión, rutas y servicios compartidos. `test/features/` cubre repositorios, controladores y widgets de dominio. Los probes de `test/browser/` y `test/manual/` sirven para comprobaciones dirigidas. Hay pruebas de funciones Edge y validadores SQL en `supabase/functions/` y `tool/`. `processing/tours/tests/` contiene pruebas del worker, runner y operaciones de imagen. Los comandos reproducibles de esta edición están en la [auditoría técnica](auditoria-tecnica.md).

**PENDIENTE DE VALIDACIÓN.** La cobertura cuantitativa, pruebas con Supabase real, resolución de mapas con token, cámara, sensores, RA, entrega de correo y push, así como la ejecución real de Cloud Run, requieren corridas específicas. Los mocks comprueban los contratos y casos implementados de cada prueba. En particular, las pruebas de mapa con superficie simulada no certifican renderizado GPU o gestos nativos.

<a id="cap-13"></a>
## 13 · Operación y mantenimiento

| Síntoma | Comprobación inicial | Evidencia |
|---|---|---|
| Pantalla de configuración | Confirmar que los defines llegaron al comando y corresponden al destino. Comprobar validación adicional en desarrollo. | `AppConfig.validationMessage`, `_initializeApp()` |
| Registro o confirmación no avanza | Consultar política y versiones, habilitación de registro, plantilla y entrega SMTP. Revisar callback con cuenta de prueba propia. | `registration_policy`, `supabase/email-templates/`, `docs/email-setup.md` |
| Un enlace Web devuelve 404 | Recargar una ruta protegida y comprobar fallback a `index.html` en el alojamiento. | `usePathUrlStrategy()`, `README.md` |
| El mapa aparece sin cartografía | Revisar define Mapbox, alcance del token, carga del estilo y conectividad. Un `PGRST202` del repositorio apunta al contrato de misiones. | `mapbox_configuration.dart`, `mission_map_repository.dart` |
| Una historia falla tras un despliegue | Comparar argumentos de `publish_story`, columnas `category`/`target_type` y caché PostgREST. | `stories_repository.dart`, migraciones `034`–`040` |
| Push Android sin entrega | Verificar permiso, dispositivo, preferencias, activación, worker y credenciales FCM. Consultar resultado de la cola. | `docs/android-push.md`, `014_android_push.sql`, `send-push/index.ts` |
| Panorama queda en cola | Revisar estado, intentos, lease, despachos y logs del job. Si el problema es de captura, revisar manifiesto, GPano y cobertura real. | `015_tours.sql`, `worker.py`, `processing/tours/README.md` |

*Tabla 7. Diagnóstico por componente. Empezar por lecturas y comprobaciones locales en el destino autorizado.*

![Estados internos del job](diagramas/11-estados-tours.svg)

*Figura 11. Estados internos del job 360°. Un lease vencido se recupera según los intentos restantes. La respuesta al cliente proyecta estados como `running`, `ready` y `needs_recapture`.*

**VERIFICADO.** El worker emite eventos estructurados con código de error, fase, duración e ID de job. El handler de geocodificación emite diagnóstico de etapa y estado del proveedor. Durante una incidencia, correlacionar versiones de cliente, migraciones y registros por entorno y usar IDs sintéticos al compartir ejemplos. Para actualizar dependencias, revisar el lockfile y ejecutar análisis, suites del dominio y compilación de los destinos afectados. El ajuste Kotlin del plugin Mapbox se revisa cuando cambie el toolchain. Véanse `worker.py`, `geocoding/index.ts`, `android/build.gradle.kts` y `docs/mapbox-validation.md`.

**PENDIENTE DE VALIDACIÓN.** Confirmar responsables, alertas, conservación de logs, política de copias, objetivos de recuperación y restauración coordinada de Auth, PostgreSQL y Storage. Los scripts locales y los ensayos previos aportan procedimientos acotados. La restauración y retención del entorno alojado requieren comprobación independiente.

<a id="cap-14"></a>
## 14 · Limitaciones, riesgos y deuda técnica

| Hallazgo | Estado e impacto | Consecuencia verificable o pendiente |
|---|---|---|
| H01 · Prefijos de migración duplicados | **VERIFICADO · Alto** | Dos archivos por versión `034` y `035`. La correspondencia con el historial efectivo del destino requiere validación antes de aplicar cambios. |
| H02 · Selección de misión desde el organizador | **VERIFICADO · Alto** | `confirm_mission_selection` admite misiones cerradas futuras y acepta candidaturas pendientes bajo sus comprobaciones. Confirmar el alcance normativo del consentimiento y cierre. |
| H03 · Cartografía real y dispositivos | **PENDIENTE DE VALIDACIÓN · Alto** | Faltan aceptación visual y gestual con token válido, prueba física de RA y medición de rendimiento en dispositivos representativos. |
| H04 · Firma Android de distribución | **VERIFICADO · Alto** | `release` referencia firma debug en el Gradle inspeccionado. Falta verificar la cadena de firma y publicación de un artefacto distribuible. |
| H05 · Suite Flutter con fallos | **VERIFICADO · Medio** | Hay 17 fallos actuales de bienvenida, feed y escaparates. Impiden registrar una suite Flutter verde. |
| H06 · Sesión y bajas | **INFERIDO · Alto** | Confirmar duración efectiva de tokens, revocación y consistencia de la supresión tras una restauración. El repositorio implementa coordinación de baja y limpieza, y usa almacenamiento local para sesión. |
| H07 · Geocodificación y procesamiento externo | **PENDIENTE DE VALIDACIÓN · Medio** | La operación depende de proveedor, límites, credenciales y cuotas. Validar integración real y recursos para una captura completa. |
| H08 · Realtime de chat | **PENDIENTE DE VALIDACIÓN · Medio** | El cliente suscribe `chat_messages`. Confirmar publicación y entrega de eventos en el destino, además de la lectura bajo RLS. |

*Tabla 8. Hallazgos de esta edición. El impacto se refiere a la capacidad de desplegar, operar o sostener el contrato del sistema. La auditoría amplía fuentes y límites.*

<a id="cap-15"></a>
## 15 · Anexos técnicos

### 15.1 Glosario

| Término | Uso en el manual |
|---|---|
| C4 | Niveles de contexto, contenedores y componentes. |
| RLS | Políticas PostgreSQL que controlan el acceso a filas. |
| RPC | Función de PostgreSQL invocada a través de la API de datos. |
| JWT | Token de sesión o credencial firmada según el flujo. |
| FCM | Firebase Cloud Messaging, transporte de push Android. |
| GPano | Metadatos XMP de panorama que el worker usa para validar importaciones. |
| Lease | Reserva temporal que identifica quién puede procesar o completar un trabajo. |
| RA | Realidad aumentada mediante ARCore o ARKit en el recorrido. |

*Tabla 9. Términos usados en los contratos y procedimientos.*

### 15.2 Fuentes y mantenimiento documental

- [Auditoría técnica](auditoria-tecnica.md) y [matriz de trazabilidad](matriz-trazabilidad.md).
- [Inventario del gate y verificadores](../../tool/README.md) y [trazabilidad de requisitos](../../tool/traceability/README.md).
- [Mapa](../map.md), [validación de Mapbox](../mapbox-validation.md), [misiones](../missions-redesign.md) y [acceso](../account-completion.md).
- [Push Android](../android-push.md), [procesador 360°](../../processing/tours/README.md) y [canales nativos](../implementation/tours-native.md).
- [Fuentes DOT y SVG](diagramas/) y [regeneración del PDF](edicion/README.md).

Actualizar el capítulo y su evidencia juntos cuando cambie un contrato. Registrar la revisión inspeccionada, las pruebas que se repitieron y las comprobaciones pendientes. Regenerar las figuras y el PDF a partir del Markdown y las fuentes DOT.
