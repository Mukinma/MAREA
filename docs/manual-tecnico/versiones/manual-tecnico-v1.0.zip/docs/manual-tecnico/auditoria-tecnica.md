# Auditoría técnica de MAREA

11 de noviembre de 2026 · Revisión base `e27f6ae4e3fb2a63f7287bbd486e989745bab216` · Árbol de trabajo con cambios locales de Mapbox

Esta auditoría acompaña al [manual](manual-tecnico.md). La [matriz](matriz-trazabilidad.md) localiza la implementación y las pruebas. **VERIFICADO** se refiere a evidencia de código o a una corrida indicada expresamente. **INFERIDO** se reserva para consecuencias del diseño. **PENDIENTE DE VALIDACIÓN** indica evidencia que requiere otro entorno, dispositivo o responsable.

## Inventario comprobado

| Capa | Elementos encontrados | Evidencia primaria |
|---|---|---|
| Aplicación | Flutter/Dart, Material, `go_router`, repositorios Supabase, controladores y vistas Android/iOS/Web. Versión de paquete `1.0.0+1`. | `pubspec.yaml`, `pubspec.lock`, `.metadata`, `lib/main.dart`, `lib/app.dart` |
| Datos | PostgreSQL, Auth, Storage, PostgREST, RPC y streams. 42 archivos SQL numerados `001`–`040`. | `supabase/migrations/`, `supabase/config.toml`, repositorios Dart |
| Integraciones | Google OAuth y correo desde Auth, Mapbox Flutter/Web `3.34.2`, geocodificación configurable con Nominatim por defecto, FCM Android y Cloud Run Jobs. | `auth_repository.dart`, `pubspec.lock`, `021_content_cities.sql`, Edge Functions y `deploy.sh` |
| Edge Functions | `delete-account`, `profile-media`, `geocoding`, `send-push`, `story-cleanup`, `tour-dispatch`. | `supabase/functions/*/index.ts`, `supabase/config.toml` |
| Worker | Imagen Python 3.12, Hugin/Enblend y dependencias fijadas Pillow, NumPy y Requests. Runner local separado. | `processing/tours/Dockerfile`, `requirements.txt`, `worker.py`, `local_runner.py` |
| Entrega y pruebas | Gradle 9.1.0, AGP 9.0.1, Kotlin 2.3.20, objetivo JVM 17, iOS 15 con SwiftPM. Gates Node, pruebas Flutter y laboratorios SQL/PGlite. | `android/`, `ios/`, `test/`, `tool/`, `processing/tours/tests/` |

La inspección cubrió entradas y configuración, dependencias, repositorios y flujos principales, contratos SQL y sus redefiniciones, almacenamiento, funciones Edge, worker y guías de operación. `docs/evidence/`, `docs/task002/` y sus laboratorios se tomaron como contexto de validaciones puntuales. Su contenido y la adopción normativa del SRS requieren revisiones propias. El inventario estático no acredita la paridad del esquema alojado con los 42 archivos.

## Comportamiento verificado e inferencias

- **VERIFICADO.** `startMarea()` construye el cliente y el router desde un controlador de sesión con repositorios inyectados. Los roles de perfil y los permisos de recurso se aplican en dominios distintos. Los guards del cliente dirigen la UI y el backend autoriza operaciones y visibilidad.
- **VERIFICADO.** Las operaciones asíncronas de tours usan reclamación, lease, guardas de escritura y recuperación. La baja consulta una marca de eliminación, espera operaciones protegidas y limpia Storage antes de eliminar el usuario.
- **VERIFICADO.** Las funciones de perfil y baja validan al usuario. Los tres workers aplican sus credenciales de servidor. `geocoding` separa lectura de lugares y resolución de contenido. El RPC `community_profiles` proyecta el directorio de perfiles y el username anónimo se consulta por booleano.
- **INFERIDO.** Los repositorios y la fachada de mapa permiten cambiar implementaciones de I/O en pruebas sin replicar la interfaz visual. Los límites reales de performance, cuotas y dispositivo necesitan pruebas con los proveedores configurados.
- **INFERIDO.** Una baja coordinada reduce residuos y escrituras posteriores. Su completitud ante restauración, trabajos interrumpidos y vigencia de credenciales necesita verificación operacional.

## Discrepancias con guías y resultados previos

| ID | Referencia anterior | Evidencia en el árbol inspeccionado |
|---|---|---|
| D01 | El `README.md` enlaza `docs/instalacion-local.md`. | La ruta está ausente. Los capítulos 09 y 10 reconstruyen los pasos con los ejemplos, código y guías disponibles. |
| D02 | El árbol del README enumera `005_mission_management.sql` y termina en `008`. | La migración se llama `005_mission_lifecycle.sql`. El inventario incluye `009`–`040` y los prefijos repetidos `034` y `035`. |
| D03 | El README describe `lib/main.dart` como única entrada ejecutable. | Es la entrada ordinaria. Gradle también identifica dos entradas de QA, `test/manual/business_ar_probe.dart` y `test/manual/business_ar_live_probe.dart`, restringidas a debug. |
| D04 | El gate inicial se presenta como verificación antes de distribuir. | `tool/backend_contract.sql` exige `001`–`015`. Hay gates separados para `016`–`019` y `020`–`021`. Las migraciones posteriores requieren sus comprobaciones de destino. |
| D05 | `docs/deployment-status.md` incluye una observación histórica de SMTP desactivado. El README y `docs/email-setup.md` reportan activación posterior y plantillas de confirmación. | El repositorio contiene plantillas y flujos de Auth. El estado de SMTP y la entrega efectiva se mantienen pendientes en esta edición. |
| D06 | El mensaje de error de `stories_repository.dart` cita `016`, `018`, `019` y `034`. | La firma actual del cliente envía cinco parámetros. La secuencia de reparación incluye `036`–`040`. Para diagnosticar el entorno revisar firmas, columnas y caché. |

## Hallazgos revisados

| ID | Estado e impacto | Evidencia y límite |
|---|---|---|
| H01 | **VERIFICADO · Alto** | `034_profile_wave_colors.sql` comparte prefijo con `034_story_metadata.sql`. `035_profile_public_interests.sql` comparte prefijo con `035_reload_postgrest_schema.sql`. Las redefiniciones y el historial remoto deben reconciliarse antes de promover un entorno. |
| H02 | **VERIFICADO · Alto** | `013_missions_redesign.sql` · `confirm_mission_selection` admite `open` o `closed`, valida cupo y llama a `review_application(...,'accepted')`. Confirma la observación de FND-011/027/028 sobre esta ruta. La aceptación normativa del flujo requiere revisión del equipo. |
| H03 | **PENDIENTE DE VALIDACIÓN · Alto** | `docs/mapbox-validation.md` distingue pruebas y compilaciones sin token de cartografía real. Las pruebas con adaptador falso y el código ARCore/ARKit permiten preparar las comprobaciones físicas. |
| H04 | **VERIFICADO · Alto** | `android/app/build.gradle.kts` · `buildTypes.release` usa `signingConfigs.getByName("debug")`. Faltan evidencia de firma de distribución y publicación actual. |
| H05 | **VERIFICADO · Medio** | La corrida de esta edición conserva 17 fallos agrupados 7/3/7 en las mismas tres suites que el informe del 7 de noviembre. Se registran los recuentos por corrida. |
| H06 | **INFERIDO · Alto** | `lib/main.dart` usa `SharedPreferencesLocalStorage` explícitamente en desarrollo y piloto. `delete-account` valida la sesión y coordina supresión. Respecto de FND-004/030/033/037, quedan por verificar la protección efectiva del almacenamiento por entorno, los tiempos de revocación y el comportamiento tras recuperación. |
| H07 | **PENDIENTE DE VALIDACIÓN · Medio** | `021_content_cities.sql` define proveedor, caché y lease. `deploy.sh` y `activate.sql` configuran Cloud Run y despacho 360°. Validar en destino credenciales, cuotas, gasto y procesamiento de una captura real. |
| H08 | **PENDIENTE DE VALIDACIÓN · Medio** | `chat_repository.dart` · `changes()` observa `chat_messages`. La búsqueda de publicación Realtime local encontró una adición explícita para `notifications` en `009_post_reactions.sql`. La entrega efectiva de eventos de chat necesita comprobarse en destino. |

FND corresponde al [informe previo](../MAREA_AUDIT_REPORT.md). Se conserva como evidencia histórica. Esta edición corrobora los puntos de código citados y deja pendientes las afirmaciones de operación que dependen de otra revisión o del entorno.

## Comprobaciones realizadas

### Flutter

El primer intento con el lanzador `flutter` encontró el SDK instalado fuera del área escribible. Se reutilizaron su snapshot y la resolución local de paquetes en una copia temporal. El primer runner dentro del entorno restringido recibió `Operation not permitted` al abrir el socket local. La corrida con acceso loopback completó la suite. En esa primera corrida faltó la carpeta de destino del arnés de capturas. Se creó la carpeta solo en la copia temporal y se repitió la suite completa.

| Comando equivalente | Resultado final del 11 de noviembre de 2026 |
|---|---|
| `flutter analyze --no-pub` | Sin incidencias. |
| `flutter test --no-pub --reporter expanded` | 653 aprobadas, 2 omitidas, 17 fallidas. Fallos por archivo: 7 en `mobile_intro_test.dart`, 3 en `home_feed_experience_test.dart`, 7 en `showcase_flow_test.dart`. |

`docs/mapbox-validation.md` registra, el 7 de noviembre, 649 aprobadas, 2 omitidas y 17 fallidas en la suite completa, 54 aprobadas en selección dirigida y builds Web, APK debug e iOS sin firma. Es un registro histórico. La evidencia de arranque sin token se limita al estado de configuración y la interfaz disponible en esas condiciones.

### Node y Python

```sh
node --test tool/traceability/traceability.test.mjs \
  test/tool/backend_contract_test.mjs \
  supabase/functions/geocoding/geocoding_test.mjs \
  supabase/functions/geocoding/lease_test.mjs

PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=processing/tours \
  .venv-tours/bin/python -m unittest discover \
  -s processing/tours/tests -p test_worker.py
```

**VERIFICADO.** Node 24 completó **55 pruebas**. El gate usó una CLI simulada y la geocodificación usó fixtures. Python completó **16 pruebas** de validación e importación del worker con I/O externo simulado. La guía de `processing/tours/` describe cómo preparar un entorno Python equivalente. Las corridas no midieron cobertura ni usaron servicios remotos.

## Validaciones pendientes

- Comparar el esquema desplegado y su historial con el DDL inspeccionado, incluidas firmas de historias, políticas, Realtime de chat y estado de funciones y procesos programados.
- Verificar acceso completo con registro nuevo, OAuth, recuperación y entrega SMTP. Comprobar FCM en Android real. Confirmar la firma y distribución Android, iOS y Web por separado.
- Probar Mapbox con token válido en las tres plataformas, captura física y RA en dispositivos compatibles, y procesamiento completo en Cloud Run con una captura autorizada.
- Confirmar responsabilidades operativas, alertas, copias y restauración de base y objetos, y revocación de credenciales tras la baja.

## Control de la edición entregada

**VERIFICADO.** El PDF A4 tiene 24 páginas y 16 marcadores. Se comprobó que los 32 enlaces del índice coinciden con los destinos de capítulo. Se renderizaron y revisaron las 24 páginas, incluidas tablas, pies de figura, tipografía y márgenes. Los 11 archivos DOT generaron SVG válidos y figuras vectoriales en el PDF. Se verificaron 266 referencias internas y locales del Markdown. La comparación por SHA-256 conservó las 1423 rutas previas al trabajo. Los 29 archivos nuevos corresponden al manual, su evidencia y sus recursos de edición.
